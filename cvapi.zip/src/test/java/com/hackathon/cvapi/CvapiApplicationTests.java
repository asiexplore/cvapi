package com.hackathon.cvapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CvapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
