package com.hackathon.cvapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CvapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CvapiApplication.class, args);
	}

}
